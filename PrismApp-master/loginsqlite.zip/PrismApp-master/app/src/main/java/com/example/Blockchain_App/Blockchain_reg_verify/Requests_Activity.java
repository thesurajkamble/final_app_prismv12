package com.example.Blockchain_App.Blockchain_reg_verify;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.Blockchain_App.R;

public class Requests_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requests);
    }
}